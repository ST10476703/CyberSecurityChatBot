﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CyberSecurityChatbotV03
{
    public class ReminderSystem
    {
        private System.Windows.Forms.Timer checkTimer;
        private DatabaseManager dbManager;
        private HashSet<int> alertedTaskIds;

        public ReminderSystem(DatabaseManager db)
        {
            dbManager = db;
            alertedTaskIds = new HashSet<int>();

            // Set up a timer to check every 1 minute (60,000 milliseconds)
            checkTimer = new System.Windows.Forms.Timer();
            checkTimer.Interval = 60000;
            checkTimer.Tick += CheckForDueTasks;
        }

        public void Start()
        {
            checkTimer.Start();
            // Run an immediate check on startup
            CheckForDueTasks(this, EventArgs.Empty);
        }

        public void Stop()
        {
            checkTimer.Stop();
        }

        private void CheckForDueTasks(object sender, EventArgs e)
        {
            var allTasks = dbManager.GetAllTasks();
            var now = DateTime.Now;

            // Find tasks due within the next 15 minutes that aren't completed and haven't been alerted yet
            var dueTasks = allTasks.Where(t =>
                !t.IsCompleted &&
                !alertedTaskIds.Contains(t.Id) &&
                t.DueDate <= now.AddMinutes(15) &&
                t.DueDate >= now.AddMinutes(-60)).ToList(); // Don't alert for tasks more than an hour overdue

            foreach (var task in dueTasks)
            {
                MessageBox.Show(
                    $"Reminder: {task.Title}\nDue at: {task.DueDate.ToShortTimeString()}\n\n{task.Description}",
                    "Task Reminder",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                alertedTaskIds.Add(task.Id);
            }
        }
    }
}