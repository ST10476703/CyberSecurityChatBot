﻿namespace CyberSecurityChatbotV03
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            pnlSidebar = new Panel();
            btnNavLogs = new Button();
            btnNavQuiz = new Button();
            btnNavTasks = new Button();
            btnNavChat = new Button();
            pnlContent = new Panel();
            pnlSidebar.SuspendLayout();
            SuspendLayout();
            // 
            // pnlSidebar
            // 
            pnlSidebar.BackColor = Color.FromArgb(24, 24, 29);
            pnlSidebar.Controls.Add(btnNavLogs);
            pnlSidebar.Controls.Add(btnNavQuiz);
            pnlSidebar.Controls.Add(btnNavTasks);
            pnlSidebar.Controls.Add(btnNavChat);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Location = new Point(0, 0);
            pnlSidebar.Name = "pnlSidebar";
            pnlSidebar.Size = new Size(200, 553);
            pnlSidebar.TabIndex = 0;
            // 
            // btnNavLogs
            // 
            btnNavLogs.Dock = DockStyle.Top;
            btnNavLogs.FlatAppearance.BorderSize = 0;
            btnNavLogs.FlatStyle = FlatStyle.Flat;
            btnNavLogs.ForeColor = Color.White;
            btnNavLogs.Location = new Point(0, 150);
            btnNavLogs.Name = "btnNavLogs";
            btnNavLogs.Size = new Size(200, 50);
            btnNavLogs.TabIndex = 3;
            btnNavLogs.Text = "System Logs";
            btnNavLogs.UseVisualStyleBackColor = true;
            btnNavLogs.Click += btnNavLogs_Click;
            // 
            // btnNavQuiz
            // 
            btnNavQuiz.Dock = DockStyle.Top;
            btnNavQuiz.FlatAppearance.BorderSize = 0;
            btnNavQuiz.FlatStyle = FlatStyle.Flat;
            btnNavQuiz.ForeColor = Color.White;
            btnNavQuiz.Location = new Point(0, 100);
            btnNavQuiz.Name = "btnNavQuiz";
            btnNavQuiz.Size = new Size(200, 50);
            btnNavQuiz.TabIndex = 2;
            btnNavQuiz.Text = "Cyber Quiz";
            btnNavQuiz.UseVisualStyleBackColor = true;
            btnNavQuiz.Click += btnNavQuiz_Click;
            // 
            // btnNavTasks
            // 
            btnNavTasks.Dock = DockStyle.Top;
            btnNavTasks.FlatAppearance.BorderSize = 0;
            btnNavTasks.FlatStyle = FlatStyle.Flat;
            btnNavTasks.ForeColor = Color.White;
            btnNavTasks.Location = new Point(0, 50);
            btnNavTasks.Name = "btnNavTasks";
            btnNavTasks.Size = new Size(200, 50);
            btnNavTasks.TabIndex = 1;
            btnNavTasks.Text = "Task Assistant";
            btnNavTasks.UseVisualStyleBackColor = true;
            btnNavTasks.Click += btnNavTasks_Click;
            // 
            // btnNavChat
            // 
            btnNavChat.Dock = DockStyle.Top;
            btnNavChat.FlatAppearance.BorderSize = 0;
            btnNavChat.FlatStyle = FlatStyle.Flat;
            btnNavChat.ForeColor = Color.White;
            btnNavChat.Location = new Point(0, 0);
            btnNavChat.Name = "btnNavChat";
            btnNavChat.Size = new Size(200, 50);
            btnNavChat.TabIndex = 0;
            btnNavChat.Text = "Chat Terminal";
            btnNavChat.UseVisualStyleBackColor = true;
            btnNavChat.Click += btnNavChat_Click;
            // 
            // pnlContent
            // 
            pnlContent.BackColor = Color.FromArgb(30, 30, 36);
            pnlContent.Dock = DockStyle.Fill;
            pnlContent.Location = new Point(200, 0);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(682, 553);
            pnlContent.TabIndex = 1;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(882, 553);
            Controls.Add(pnlContent);
            Controls.Add(pnlSidebar);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cyber Intelligence System Dashboard";
            pnlSidebar.ResumeLayout(false);
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Button btnNavChat;
        private System.Windows.Forms.Panel pnlContent;
        private System.Windows.Forms.Button btnNavLogs;
        private System.Windows.Forms.Button btnNavQuiz;
        private System.Windows.Forms.Button btnNavTasks;
    }
}