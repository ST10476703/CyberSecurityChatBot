﻿namespace CyberSecurityChatbotV03
{
    partial class QuizModule
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblScore = new Label();
            lblQuestion = new Label();
            btnOptionA = new Button();
            btnOptionB = new Button();
            btnOptionC = new Button();
            btnOptionD = new Button();
            lblFeedback = new Label();
            btnNext = new Button();
            label1 = new Label();
            lblWelcome = new Label();
            trackBar1 = new TrackBar();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            SuspendLayout();
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblScore.Location = new Point(485, 107);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(120, 28);
            lblScore.TabIndex = 0;
            lblScore.Text = "Score: 0/10";
            // 
            // lblQuestion
            // 
            lblQuestion.Location = new Point(75, 179);
            lblQuestion.Name = "lblQuestion";
            lblQuestion.Size = new Size(710, 25);
            lblQuestion.TabIndex = 1;
            lblQuestion.Text = "Questions will appear here:";
            // 
            // btnOptionA
            // 
            btnOptionA.Location = new Point(75, 207);
            btnOptionA.Name = "btnOptionA";
            btnOptionA.Size = new Size(478, 29);
            btnOptionA.TabIndex = 2;
            btnOptionA.Text = "A";
            btnOptionA.UseVisualStyleBackColor = true;
            btnOptionA.Click += btnOptionA_Click;
            // 
            // btnOptionB
            // 
            btnOptionB.Location = new Point(75, 242);
            btnOptionB.Name = "btnOptionB";
            btnOptionB.Size = new Size(478, 29);
            btnOptionB.TabIndex = 3;
            btnOptionB.Text = "B";
            btnOptionB.UseVisualStyleBackColor = true;
            btnOptionB.Click += btnOptionB_Click;
            // 
            // btnOptionC
            // 
            btnOptionC.Location = new Point(75, 277);
            btnOptionC.Name = "btnOptionC";
            btnOptionC.Size = new Size(478, 29);
            btnOptionC.TabIndex = 4;
            btnOptionC.Text = "C";
            btnOptionC.UseVisualStyleBackColor = true;
            btnOptionC.Click += btnOptionC_Click;
            // 
            // btnOptionD
            // 
            btnOptionD.Location = new Point(75, 312);
            btnOptionD.Name = "btnOptionD";
            btnOptionD.Size = new Size(478, 29);
            btnOptionD.TabIndex = 5;
            btnOptionD.Text = "D";
            btnOptionD.UseVisualStyleBackColor = true;
            btnOptionD.Click += btnOptionD_Click;
            // 
            // lblFeedback
            // 
            lblFeedback.AutoSize = true;
            lblFeedback.BackColor = Color.Lime;
            lblFeedback.Location = new Point(584, 251);
            lblFeedback.Name = "lblFeedback";
            lblFeedback.Size = new Size(21, 20);
            lblFeedback.TabIndex = 6;
            lblFeedback.Text = "\"\"";
            // 
            // btnNext
            // 
            btnNext.Location = new Point(584, 316);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(94, 29);
            btnNext.TabIndex = 7;
            btnNext.Text = "Next";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(378, 320);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 8;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Location = new Point(75, 107);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(167, 20);
            lblWelcome.TabIndex = 9;
            lblWelcome.Text = "Test your understanding";
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(75, 351);
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(530, 56);
            trackBar1.TabIndex = 10;
            // 
            // QuizModule
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(trackBar1);
            Controls.Add(lblWelcome);
            Controls.Add(label1);
            Controls.Add(btnNext);
            Controls.Add(lblFeedback);
            Controls.Add(btnOptionD);
            Controls.Add(btnOptionC);
            Controls.Add(btnOptionB);
            Controls.Add(btnOptionA);
            Controls.Add(lblQuestion);
            Controls.Add(lblScore);
            Name = "QuizModule";
            Size = new Size(926, 435);
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblScore;
        private Label lblQuestion;
        private Button btnOptionA;
        private Button btnOptionB;
        private Button btnOptionC;
        private Button btnOptionD;
        private Label lblFeedback;
        private Button btnNext;
        private Label label1;
        private Label lblWelcome;
        private TrackBar trackBar1;
    }
}
