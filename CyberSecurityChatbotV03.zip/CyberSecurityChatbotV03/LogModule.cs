﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CyberSecurityChatbotV03
{
    public partial class LogModule : UserControl
    {
        private List<string> allLogs = new List<string>();
        private int currentPage = 1;
        private readonly int itemsPerPage = 8; // Rubric asks for 5-10 items at a time

        public LogModule()
        {
            InitializeComponent();
            this.Load += LogModule_Load;
        }

        private void LogModule_Load(object sender, EventArgs e)
        {
            LoadLogData();
            DisplayPage(1);
        }

        private void LoadLogData()
        {
            string logFilePath = "log.txt";

            if (File.Exists(logFilePath))
            {
                // Read all lines, remove empty ones, and reverse so newest is first
                allLogs = File.ReadAllLines(logFilePath)
                              .Where(line => !string.IsNullOrWhiteSpace(line))
                              .Reverse()
                              .ToList();
            }
            else
            {
                allLogs.Add("System Notice: No activity logs found yet.");
            }
        }

        private void DisplayPage(int pageNumber)
        {
            lstLogs.Items.Clear();

            int totalItems = allLogs.Count;
            int totalPages = (int)Math.Ceiling((double)totalItems / itemsPerPage);

            // Safety check for empty logs
            if (totalPages == 0) totalPages = 1;

            // Ensure page bounds are respected
            if (pageNumber < 1) pageNumber = 1;
            if (pageNumber > totalPages) pageNumber = totalPages;

            currentPage = pageNumber;

            // Calculate which items to pull for the current page
            int startIndex = (currentPage - 1) * itemsPerPage;
            var pageItems = allLogs.Skip(startIndex).Take(itemsPerPage).ToList();

            // Populate the ListBox
            foreach (var item in pageItems)
            {
                lstLogs.Items.Add($"[LOG] {item}");
            }

            // Update UI elements
            lblPageInfo.Text = $"Page {currentPage} of {totalPages}";
            btnPrev.Enabled = currentPage > 1;
            btnNext.Enabled = currentPage < totalPages;
        }

        // --- UI Events (Link these in the Designer) ---
        private void btnPrev_Click(object sender, EventArgs e)
        {
            DisplayPage(currentPage - 1);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            DisplayPage(currentPage + 1);
        }
    }
}