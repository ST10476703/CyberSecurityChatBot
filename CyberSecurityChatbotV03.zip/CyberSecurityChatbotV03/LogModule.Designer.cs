﻿namespace CyberSecurityChatbotV03
{
    partial class LogModule
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lstLogs = new ListBox();
            btnPrev = new Button();
            btnNext = new Button();
            lblPageInfo = new Label();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(112, 76);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(300, 38);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Systems Activity Logs";
            // 
            // lstLogs
            // 
            lstLogs.BackColor = Color.FromArgb(45, 45, 53);
            lstLogs.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lstLogs.ForeColor = Color.FromArgb(0, 255, 163);
            lstLogs.FormattingEnabled = true;
            lstLogs.Location = new Point(110, 188);
            lstLogs.Name = "lstLogs";
            lstLogs.Size = new Size(543, 303);
            lstLogs.TabIndex = 1;
            // 
            // btnPrev
            // 
            btnPrev.Location = new Point(121, 507);
            btnPrev.Name = "btnPrev";
            btnPrev.Size = new Size(94, 29);
            btnPrev.TabIndex = 2;
            btnPrev.Text = "Previous Page";
            btnPrev.UseVisualStyleBackColor = true;
            btnPrev.Click += btnPrev_Click;
            // 
            // btnNext
            // 
            btnNext.Location = new Point(412, 503);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(94, 29);
            btnNext.TabIndex = 3;
            btnNext.Text = "Next Page";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // lblPageInfo
            // 
            lblPageInfo.AutoSize = true;
            lblPageInfo.Location = new Point(706, 503);
            lblPageInfo.Name = "lblPageInfo";
            lblPageInfo.Size = new Size(83, 20);
            lblPageInfo.TabIndex = 4;
            lblPageInfo.Text = "Page 1 of 1";
            // 
            // LogModule
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lblPageInfo);
            Controls.Add(btnNext);
            Controls.Add(btnPrev);
            Controls.Add(lstLogs);
            Controls.Add(lblTitle);
            Name = "LogModule";
            Size = new Size(880, 579);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private ListBox lstLogs;
        private Button btnPrev;
        private Button btnNext;
        private Label lblPageInfo;
    }
}
