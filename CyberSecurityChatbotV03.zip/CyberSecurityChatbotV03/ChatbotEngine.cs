﻿using System;
using System.Collections.Generic;

namespace CyberSecurityChatbotV03
{
    public class ChatbotEngine
    {
        private InputProcessor inputProcessor = new InputProcessor();
        private Random randomizer = new Random();

        // Dictionary containing arrays of varied responses for every topic
        private readonly Dictionary<string, string[]> responseBank = new Dictionary<string, string[]>
        {
            { "greeting", new[] {
                "Hello! How can I help you secure your systems today?",
                "Greetings! What cybersecurity topic would you like to explore?",
                "Hi there! Ready to talk about online safety?"
            }},
            { "gratitude", new[] {
                "You are very welcome. Stay safe online!",
                "My pleasure. Let me know if you need anything else.",
                "Happy to help!"
            }},
            { "password", new[] {
                "Always use a passphrase over 12 characters with mixed symbols and numbers.",
                "Avoid reusing passwords across sites. A password manager is your best defense.",
                "Password strength is critical. Never use personal info like pet names or birthdays."
            }},
            { "phishing", new[] {
                "Phishing attacks rely on urgency. Never click links in emails you didn't expect.",
                "If an email asks for your password or financial info, it's a scam. Verify with the sender directly.",
                "Hover over links to see the real destination before clicking. Attackers spoof trusted brands."
            }},
            { "malware", new[] {
                "Malware can infect your system through bad downloads or infected drives. Keep Windows Defender active.",
                "If your system is suddenly very slow or showing weird popups, run a full antivirus scan immediately.",
                "Never download software from third-party sites. Stick to official vendors."
            }},
            { "mfa", new[] {
                "Multi-Factor Authentication (MFA) blocks 99.9% of automated attacks. Turn it on everywhere.",
                "2FA requires something you know (password) and something you have (your phone). It is essential.",
                "An authenticator app is generally more secure than receiving 2FA codes via SMS."
            }},
            { "vpn", new[] {
                "A VPN encrypts your traffic, keeping it safe from packet sniffers on public networks.",
                "Use a VPN when connecting to untrusted Wi-Fi to create a secure tunnel for your data."
            }},
            { "publicwifi", new[] {
                "Never log into your bank or sensitive accounts on public Wi-Fi without a VPN.",
                "Public Wi-Fi is often unencrypted. Anyone on the network can potentially see your traffic."
            }},
            { "ransomware", new[] {
                "Ransomware encrypts your files and demands payment. The best defense is offline backups.",
                "Never pay the ransom. There is no guarantee you will get your data back. Restore from a backup instead."
            }},
            { "updates", new[] {
                "Software updates patch known vulnerabilities. Always keep your OS and apps fully updated.",
                "Delaying updates leaves you exposed to 'n-day' exploits that attackers are already scanning for."
            }},
            { "socialengineering", new[] {
                "Social engineering attacks target human psychology rather than software flaws. Stay skeptical.",
                "Scammers will try to create panic or urgency to make you bypass security protocols."
            }},
            { "firewall", new[] {
                "A firewall acts as a digital bouncer, blocking unauthorized traffic from entering your network.",
                "Ensure your OS firewall is always enabled to prevent external intrusion attempts."
            }},
            { "backups", new[] {
                "Follow the 3-2-1 rule: 3 copies of data, 2 different media types, 1 offsite copy.",
                "Backups are your ultimate failsafe against hardware failure and ransomware."
            }}
            // The engine defaults smoothly if a topic isn't fully populated here
        };

        public string ProcessInput(string userInput)
        {
            var intents = inputProcessor.AnalyzeMulti(userInput);

            if (intents.Count == 0)
            {
                return GetRandomDefaultResponse();
            }

            // Grab the strongest matched topic
            string topIntent = intents[0].Topic;

            if (responseBank.ContainsKey(topIntent))
            {
                string[] possibleResponses = responseBank[topIntent];
                int randomIndex = randomizer.Next(possibleResponses.Length);
                return possibleResponses[randomIndex];
            }

            return $"I detected you are asking about '{topIntent}', but my database is currently updating that module.";
        }

        private string GetRandomDefaultResponse()
        {
            string[] defaults = new[]
            {
                "I'm not completely sure I understand. Could you rephrase that in cybersecurity terms?",
                "That falls outside my current parameters. Are you asking about passwords, malware, or network security?",
                "I didn't quite catch that. Try asking me about phishing, VPNs, or setting up a 2FA task."
            };
            return defaults[randomizer.Next(defaults.Length)];
        }
    }
}