﻿// ========================= VOICE SERVICE =========================
using System;
using System.Speech.Synthesis;

namespace CyberSecurityChatbotV03
{
    public class VoiceService
    {
        private SpeechSynthesizer synth;

        public VoiceService()
        {
            try
            {
                synth = new SpeechSynthesizer();
                synth.SetOutputToDefaultAudioDevice();
                // Optional: You can change the voice gender here if you want
                // synth.SelectVoiceByHints(VoiceGender.Female); 
            }
            catch (Exception ex)
            {
                Console.WriteLine("Audio hardware not found: " + ex.Message);
            }
        }

        public void Speak(string text)
        {
            if (synth != null && !string.IsNullOrWhiteSpace(text))
            {
                // Stop any current speech before starting a new sentence
                synth.SpeakAsyncCancelAll();

                // SpeakAsync ensures the app doesn't freeze while talking
                synth.SpeakAsync(text);
            }
        }
    }
}