﻿using System;
using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CyberSecurityChatbotV03
{
    public partial class ChatModule : UserControl
    {
        private ChatbotEngine bot = new ChatbotEngine();
        private ProfileManager profileManager = new ProfileManager();
        private MemoryManager memory = new MemoryManager();
        private DatabaseManager dbManager;
        private Logger logger = new Logger();

        // Task 1: Voice Integration
        private VoiceService voiceEngine = new VoiceService();
        private bool isVoiceEnabled = false;

        private UserProfile profile;
        private bool isNewUser = false;
        private bool waitingForUserName = false;
        private bool waitingForBotName = false;

        public ChatModule(DatabaseManager db)
        {
            InitializeComponent();
            dbManager = db;
            this.Load += ChatModule_Load;
        }

        private void ChatModule_Load(object sender, EventArgs e)
        {
            // ===== TASK 1: ASCII ART BOOT SEQUENCE =====
            string asciiBanner = @"
  ██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
 ██╔════╝ ╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
 ██║       ╚████╔╝ ██████╔╝█████╗  ██████╔╝
 ██║        ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗
 ╚██████╗    ██║   ██████╔╝███████╗██║  ██║
  ╚═════╝    ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
=============================================";

            rtbChat.AppendText(asciiBanner + "\n\n");

            memory.Load();
            profile = profileManager.Load();
            isNewUser = (profile == null || string.IsNullOrWhiteSpace(profile.Name));

            if (isNewUser)
            {
                OutputBotMessage("Welcome to the Cyber Intelligence System.");
                OutputBotMessage("What is your designation (Name)?");
                waitingForUserName = true;
            }
            else
            {
                OutputBotMessage($"Welcome back, {profile.Name}.");
                OutputBotMessage($"I am {profile.BotName}. How can I assist you?");
                logger.Log("System access granted to user: " + profile.Name);
            }
        }

        // ===== CENTRALIZED OUTPUT ENGINE (HANDLES TEXT & VOICE) =====
        private void OutputBotMessage(string message)
        {
            string currentBotName = (profile != null && !string.IsNullOrWhiteSpace(profile.BotName)) ? profile.BotName : "System";
            rtbChat.AppendText($"{currentBotName}: {message}\n\n");

            // Trigger Text-to-Speech if enabled
            if (isVoiceEnabled)
            {
                try
                {
                    voiceEngine.Speak(message); // Uses SpeakAsync so UI doesn't freeze
                }
                catch { /* Ignore TTS errors if system audio fails */ }
            }
        }

        // ===== VOICE TOGGLE EVENT =====
        private void btnVoiceToggle_Click(object sender, EventArgs e)
        {
            isVoiceEnabled = !isVoiceEnabled; // Flip the state

            if (isVoiceEnabled)
            {
                btnVoiceToggle.Text = "VOICE: ON";
                btnVoiceToggle.BackColor = System.Drawing.Color.LimeGreen;
                OutputBotMessage("Voice interface activated.");
            }
            else
            {
                btnVoiceToggle.Text = "VOICE: OFF";
                btnVoiceToggle.BackColor = System.Drawing.Color.FromArgb(45, 45, 53); // Default dark
                rtbChat.AppendText("System: Voice interface deactivated.\n\n");
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();
            if (string.IsNullOrEmpty(input)) return;

            string currentUserName = (profile != null && !string.IsNullOrWhiteSpace(profile.Name)) ? profile.Name : "You";
            rtbChat.AppendText($"{currentUserName}: {input}\n");
            txtInput.Clear();

            // First-Time Setup Flow
            if (isNewUser)
            {
                HandleSetupFlow(input);
                return;
            }

            string normalizedInput = input.ToLowerInvariant();

            // 1. Rename Bot Intercept
            var renameMatch = Regex.Match(normalizedInput, @"\b(?:change your name to|rename (?:yourself|you) to|call yourself|your new name is)\s+([a-zA-Z0-9_-]+)\b");
            if (renameMatch.Success)
            {
                string newBotName = renameMatch.Groups[1].Value;
                profile.BotName = char.ToUpper(newBotName[0]) + newBotName.Substring(1);
                profileManager.Save(profile);

                OutputBotMessage($"Identity updated. I am now {profile.BotName}.");
                logger.Log($"User renamed the bot to {profile.BotName}");
                return;
            }

            // 2. Task Assistant Intercept
            if (Regex.IsMatch(normalizedInput, @"\b(add.*task|remind me|set.*reminder)\b"))
            {
                ExecuteTaskCommand(input);
                return;
            }

            // 3. Activity Log Intercept
            if (Regex.IsMatch(normalizedInput, @"\b(activity log|what have you done)\b"))
            {
                ExecuteLogCommand();
                return;
            }

            // ===== STANDARD CHAT FLOW =====
            string response = bot.ProcessInput(input);
            OutputBotMessage(response);
        }

        private void ExecuteTaskCommand(string input)
        {
            string taskTitle = Regex.Replace(input, @"(?i)\b(add a task to|add task to|remind me to|set a reminder to|remind me|add task)\b", "").Trim();

            if (taskTitle.Length > 0)
                taskTitle = char.ToUpper(taskTitle[0]) + taskTitle.Substring(1);
            else
                taskTitle = "New Cybersecurity Task";

            var newTask = new TaskItem
            {
                Title = taskTitle,
                Description = "Task created via terminal command.",
                DueDate = DateTime.Now.AddDays(1),
                IsCompleted = false
            };

            dbManager.AddTask(newTask);
            logger.Log($"Task added via NLP: {taskTitle}");

            OutputBotMessage($"Task added: '{taskTitle}'. A reminder has been set for tomorrow.");
        }

        private void ExecuteLogCommand()
        {
            OutputBotMessage("Here is a summary of recent actions:");

            if (File.Exists("log.txt"))
            {
                var recentLogs = File.ReadAllLines("log.txt")
                                     .Where(line => !string.IsNullOrWhiteSpace(line))
                                     .Reverse()
                                     .Take(5)
                                     .ToList();

                if (recentLogs.Count > 0)
                {
                    int index = 1;
                    foreach (var log in recentLogs)
                    {
                        rtbChat.AppendText($"  {index}. {log}\n");
                        index++;
                    }
                }
                else
                {
                    rtbChat.AppendText("  No recent actions recorded.\n");
                }
            }
            rtbChat.AppendText("\n");
            logger.Log("User requested in-terminal activity log.");
        }

        private void HandleSetupFlow(string input)
        {
            if (waitingForUserName)
            {
                if (profile == null) profile = new UserProfile();

                profile.Name = input;
                waitingForUserName = false;
                waitingForBotName = true;
                OutputBotMessage($"Designation accepted, {profile.Name}.");
                OutputBotMessage("What would you like to call me?");
                return;
            }

            if (waitingForBotName)
            {
                profile.BotName = input;
                profileManager.Save(profile);
                waitingForBotName = false;
                isNewUser = false;
                OutputBotMessage($"Acknowledged. I am {profile.BotName}.");
                OutputBotMessage("Initialization complete. Ready for queries.");
                logger.Log("New user profile configured.");
            }
        }
    }
}