﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CyberSecurityChatbotV03
{
    // Determines how the UI renders the question
    public enum QuestionType { MultipleChoice, TrueFalse, Matching }

    public partial class QuizModule : UserControl
    {
        private List<QuizQuestion> questions;
        private int currentQuestionIndex = 0;
        private int score = 0;

        public QuizModule()
        {
            InitializeComponent();
            LoadQuestionBank();
            DisplayQuestion();
        }

        private void LoadQuestionBank()
        {
            questions = new List<QuizQuestion>
            {
                // --- MULTIPLE CHOICE ---
                new QuizQuestion("What is a common indicator of a phishing email?", QuestionType.MultipleChoice, "Perfect spelling", "A generic greeting like 'Dear Customer'", "Sent during business hours", "Has an attachment", 1, "Phishing often uses generic greetings because attackers send them in bulk."),
                new QuizQuestion("Which of the following is the strongest password?", QuestionType.MultipleChoice, "Password123", "Admin2026", "MyDogSkip", "cT7$vP9@kL2#", 3, "Complex passwords with mixed cases, numbers, and symbols resist brute force attacks."),
                new QuizQuestion("What does a VPN (Virtual Private Network) do?", QuestionType.MultipleChoice, "Speeds up your internet", "Encrypts your internet traffic", "Blocks all ads", "Generates strong passwords", 1, "A VPN creates a secure, encrypted tunnel for your data."),
                new QuizQuestion("What is a 'Zero-Day' vulnerability?", QuestionType.MultipleChoice, "A bug fixed on the same day", "A newly discovered flaw with no patch yet", "A virus that deletes itself in 24 hours", "A fake antivirus alert", 1, "Zero-days are highly dangerous because developers haven't had time to create a fix."),
                new QuizQuestion("What is the main purpose of a Firewall?", QuestionType.MultipleChoice, "To cool down the server", "To block unauthorized network traffic", "To scan files for viruses", "To back up data", 1, "Firewalls act as a barrier between a trusted and an untrusted network."),
                new QuizQuestion("Which protocol is secure for web browsing?", QuestionType.MultipleChoice, "HTTP", "FTP", "Telnet", "HTTPS", 3, "The 'S' in HTTPS stands for Secure, meaning the connection is encrypted."),
                new QuizQuestion("What is Social Engineering?", QuestionType.MultipleChoice, "Hacking a firewall", "Manipulating people into giving up confidential info", "Building a social media platform", "Writing secure code", 1, "Attackers target human psychology rather than technical flaws."),
                new QuizQuestion("What does Ransomware do?", QuestionType.MultipleChoice, "Speeds up your PC", "Encrypts files and demands payment", "Deletes your browser history", "Upgrades your OS", 1, "Ransomware holds your data hostage until a fee is paid."),
                new QuizQuestion("Why use Multi-Factor Authentication (MFA)?", QuestionType.MultipleChoice, "It makes logging in faster", "It replaces the need for a password", "It adds a second layer of security", "It organizes your apps", 2, "Even if an attacker gets your password, they still need your second factor."),
                new QuizQuestion("What is the difference between a worm and a virus?", QuestionType.MultipleChoice, "Worms need a host file; viruses do not", "Viruses self-replicate across networks; worms do not", "Worms self-replicate independently; viruses need a host file", "There is no difference", 2, "Worms can spread across networks without human interaction."),

                // --- TRUE / FALSE ---
                new QuizQuestion("Incognito mode hides your browsing history from your Internet Service Provider.", QuestionType.TrueFalse, "True", "False", "", "", 1, "False. Incognito only hides history locally on your device, not from your ISP."),
                new QuizQuestion("A firewall guarantees 100% protection against all cyber threats.", QuestionType.TrueFalse, "True", "False", "", "", 1, "False. Firewalls are just one layer of defense; no single tool guarantees 100% security."),
                new QuizQuestion("Public Wi-Fi networks are generally safe if you are not accessing bank accounts.", QuestionType.TrueFalse, "True", "False", "", "", 1, "False. Attackers on public Wi-Fi can intercept passwords for any unencrypted site or inject malware."),
                new QuizQuestion("Mac computers cannot get viruses or malware.", QuestionType.TrueFalse, "True", "False", "", "", 1, "False. While historically targeted less, Macs are absolutely vulnerable to malware."),
                new QuizQuestion("Deleting an email with a suspicious attachment prevents infection.", QuestionType.TrueFalse, "True", "False", "", "", 0, "True. As long as you do not open the attachment or click links, simply receiving it will not infect you."),

                // --- MATCHING (Column Mapping) ---
                new QuizQuestion("Match the CIA Triad component to its goal: 1) Confidentiality, 2) Integrity, 3) Availability", QuestionType.Matching, "A: 1-Secret, 2-Unaltered, 3-Accessible", "B: 1-Accessible, 2-Secret, 3-Unaltered", "C: 1-Unaltered, 2-Accessible, 3-Secret", "D: 1-Secret, 2-Accessible, 3-Unaltered", 0, "Confidentiality keeps data secret. Integrity keeps it unaltered. Availability ensures access."),
                new QuizQuestion("Match the Malware to its behavior: 1) Trojan, 2) Spyware, 3) Adware", QuestionType.Matching, "A: 1-Ads, 2-Spies, 3-Disguises", "B: 1-Disguises, 2-Spies, 3-Ads", "C: 1-Spies, 2-Ads, 3-Disguises", "D: 1-Disguises, 2-Ads, 3-Spies", 1, "Trojans disguise as legitimate software. Spyware monitors activity. Adware shows ads."),
                new QuizQuestion("Match the Port Number to the Protocol: 1) Port 80, 2) Port 443, 3) Port 22", QuestionType.Matching, "A: 1-HTTPS, 2-SSH, 3-HTTP", "B: 1-SSH, 2-HTTP, 3-HTTPS", "C: 1-HTTP, 2-HTTPS, 3-SSH", "D: 1-HTTP, 2-SSH, 3-HTTPS", 2, "Port 80 is HTTP (unsecured). Port 443 is HTTPS (secured). Port 22 is SSH (remote access)."),
                new QuizQuestion("Match the Attack to its Type: 1) DDoS, 2) Keylogger, 3) SQL Injection", QuestionType.Matching, "A: 1-Database attack, 2-Overloads servers, 3-Records typing", "B: 1-Records typing, 2-Database attack, 3-Overloads servers", "C: 1-Overloads servers, 2-Records typing, 3-Database attack", "D: 1-Overloads servers, 2-Database attack, 3-Records typing", 2, "DDoS crashes servers via overload. Keyloggers steal typed data. SQLi attacks databases."),
                new QuizQuestion("Match the Authentication Factor: 1) Something you know, 2) Something you have, 3) Something you are", QuestionType.Matching, "A: 1-Phone, 2-Password, 3-Fingerprint", "B: 1-Password, 2-Phone, 3-Fingerprint", "C: 1-Fingerprint, 2-Password, 3-Phone", "D: 1-Password, 2-Fingerprint, 3-Phone", 1, "Passwords are known. Phones/Tokens are possessed. Fingerprints are biometrics (who you are).")
            };
        }

        private void DisplayQuestion()
        {
            if (currentQuestionIndex >= questions.Count)
            {
                EndQuiz();
                return;
            }

            var q = questions[currentQuestionIndex];
            lblQuestion.Text = $"Q{currentQuestionIndex + 1}: {q.QuestionText}";

            // Populate buttons
            btnOptionA.Text = q.Options[0];
            btnOptionB.Text = q.Options[1];
            btnOptionC.Text = q.Options[2];
            btnOptionD.Text = q.Options[3];

            // Dynamic UI Adjustment based on Question Type
            if (q.Type == QuestionType.TrueFalse)
            {
                btnOptionC.Visible = false;
                btnOptionD.Visible = false;
            }
            else
            {
                btnOptionC.Visible = true;
                btnOptionD.Visible = true;
            }

            // Reset UI state
            lblFeedback.Text = "";
            btnNext.Visible = false;
            EnableOptions(true);
        }

        private void CheckAnswer(int selectedIndex, Button clickedButton)
        {
            var q = questions[currentQuestionIndex];
            EnableOptions(false);
            btnNext.Visible = true;

            if (selectedIndex == q.CorrectAnswerIndex)
            {
                score++;
                lblScore.Text = $"Score: {score} / {questions.Count}";
                lblFeedback.Text = "Correct! " + q.Feedback;
                lblFeedback.ForeColor = Color.LimeGreen;
                clickedButton.BackColor = Color.LimeGreen;
            }
            else
            {
                lblFeedback.Text = "Incorrect. " + q.Feedback;
                lblFeedback.ForeColor = Color.Tomato;
                clickedButton.BackColor = Color.Tomato;
            }
        }

        private void EnableOptions(bool enable)
        {
            btnOptionA.Enabled = enable;
            btnOptionB.Enabled = enable;
            btnOptionC.Enabled = enable;
            btnOptionD.Enabled = enable;

            if (enable)
            {
                Color defaultBtnColor = Color.FromArgb(45, 45, 53);
                btnOptionA.BackColor = defaultBtnColor;
                btnOptionB.BackColor = defaultBtnColor;
                btnOptionC.BackColor = defaultBtnColor;
                btnOptionD.BackColor = defaultBtnColor;
            }
        }

        private void EndQuiz()
        {
            lblQuestion.Text = "Quiz Complete! Initializing result assessment...";
            lblFeedback.Text = $"Final Score: {score} / {questions.Count}. Returning to terminal.";
            EnableOptions(false);
            btnNext.Visible = false;

            // Ensure bottom buttons are hidden on the end screen
            btnOptionC.Visible = false;
            btnOptionD.Visible = false;
        }

        // UI Events
        private void btnOptionA_Click(object sender, EventArgs e) => CheckAnswer(0, btnOptionA);
        private void btnOptionB_Click(object sender, EventArgs e) => CheckAnswer(1, btnOptionB);
        private void btnOptionC_Click(object sender, EventArgs e) => CheckAnswer(2, btnOptionC);
        private void btnOptionD_Click(object sender, EventArgs e) => CheckAnswer(3, btnOptionD);

        private void btnNext_Click(object sender, EventArgs e)
        {
            currentQuestionIndex++;
            DisplayQuestion();
        }
    }

    // Helper Class updated to track QuestionType
    public class QuizQuestion
    {
        public string QuestionText { get; set; }
        public QuestionType Type { get; set; }
        public string[] Options { get; set; }
        public int CorrectAnswerIndex { get; set; }
        public string Feedback { get; set; }

        public QuizQuestion(string text, QuestionType type, string opA, string opB, string opC, string opD, int correct, string feedback)
        {
            QuestionText = text;
            Type = type;
            Options = new string[] { opA, opB, opC, opD };
            CorrectAnswerIndex = correct;
            Feedback = feedback;
        }
    }
}