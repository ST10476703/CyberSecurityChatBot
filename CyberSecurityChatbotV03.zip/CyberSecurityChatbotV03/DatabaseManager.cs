﻿using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using System.Security.Cryptography;
using System.Text;

namespace CyberSecurityChatbotV03
{
    public class DatabaseManager
    {
        private readonly string connectionString = "Data Source=tasks.db";

        public DatabaseManager()
        {
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            try
            {
                using (var connection = new SqliteConnection(connectionString))
                {
                    connection.Open();

                    // Keep the Tasks table
                    string taskTable = @"CREATE TABLE IF NOT EXISTS Tasks (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Title TEXT NOT NULL,
                        Description TEXT,
                        DueDate TEXT NOT NULL,
                        IsCompleted INTEGER NOT NULL DEFAULT 0
                    )";

                    // Add the new Users table
                    string userTable = @"CREATE TABLE IF NOT EXISTS Users (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Username TEXT UNIQUE NOT NULL,
                        PasswordHash TEXT NOT NULL
                    )";

                    using (var command = new SqliteCommand(taskTable, connection)) command.ExecuteNonQuery();
                    using (var command = new SqliteCommand(userTable, connection)) command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("DB Error: " + ex.Message);
            }
        }

        // ===== AUTHENTICATION (NEW Should have been old) =====

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes) builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

        public bool RegisterUser(string username, string password)
        {
            try
            {
                using (var connection = new SqliteConnection(connectionString))
                {
                    connection.Open();
                    string insertCmd = "INSERT INTO Users (Username, PasswordHash) VALUES (@User, @Hash)";
                    using (var command = new SqliteCommand(insertCmd, connection))
                    {
                        command.Parameters.AddWithValue("@User", username);
                        command.Parameters.AddWithValue("@Hash", HashPassword(password));
                        command.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch // Will fail if Username already exists (UNIQUE constraint)
            {
                return false;
            }
        }

        public bool AuthenticateUser(string username, string password)
        {
            try
            {
                using (var connection = new SqliteConnection(connectionString))
                {
                    connection.Open();
                    string selectCmd = "SELECT PasswordHash FROM Users WHERE Username = @User";
                    using (var command = new SqliteCommand(selectCmd, connection))
                    {
                        command.Parameters.AddWithValue("@User", username);
                        var result = command.ExecuteScalar();

                        if (result != null)
                        {
                            return result.ToString() == HashPassword(password);
                        }
                    }
                }
            }
            catch { }
            return false;
        }

        // ===== CRUD OPERATIONS (Existing) =====
        public void AddTask(TaskItem task)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string insertCommand = "INSERT INTO Tasks (Title, Description, DueDate, IsCompleted) VALUES (@Title, @Description, @DueDate, @IsCompleted)";
                using (var command = new SqliteCommand(insertCommand, connection))
                {
                    command.Parameters.AddWithValue("@Title", task.Title);
                    command.Parameters.AddWithValue("@Description", task.Description ?? "");
                    command.Parameters.AddWithValue("@DueDate", task.DueDate.ToString("yyyy-MM-dd HH:mm"));
                    command.Parameters.AddWithValue("@IsCompleted", task.IsCompleted ? 1 : 0);
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<TaskItem> GetAllTasks()
        {
            var tasks = new List<TaskItem>();
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string selectCommand = "SELECT * FROM Tasks ORDER BY DueDate ASC";
                using (var command = new SqliteCommand(selectCommand, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tasks.Add(new TaskItem
                        {
                            Id = reader.GetInt32(0),
                            Title = reader.GetString(1),
                            Description = reader.IsDBNull(2) ? "" : reader.GetString(2),
                            DueDate = DateTime.Parse(reader.GetString(3)),
                            IsCompleted = reader.GetInt32(4) == 1
                        });
                    }
                }
            }
            return tasks;
        }

        public void UpdateTaskStatus(int id, bool isCompleted)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string updateCommand = "UPDATE Tasks SET IsCompleted = @IsCompleted WHERE Id = @Id";
                using (var command = new SqliteCommand(updateCommand, connection))
                {
                    command.Parameters.AddWithValue("@IsCompleted", isCompleted ? 1 : 0);
                    command.Parameters.AddWithValue("@Id", id);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteTask(int id)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string deleteCommand = "DELETE FROM Tasks WHERE Id = @Id";
                using (var command = new SqliteCommand(deleteCommand, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}