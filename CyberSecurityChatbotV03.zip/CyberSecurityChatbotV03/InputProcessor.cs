﻿// ========================= INPUT PROCESSOR =========================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CyberSecurityChatbotV03
{
    public class InputProcessor
    {
        private readonly Dictionary<string, List<string>> topicPatterns = new Dictionary<string, List<string>>
        {
            // Social & Greetings
            { "greeting", new List<string> { @"\b(hi|hello|hey|greetings|morning|afternoon|evening|howdy|sup)\b", @"\b(how are you|how's it going|what's up)\b" } },
            { "gratitude", new List<string> { @"\b(thanks|thank you|appreciate it|awesome|great)\b" } },
            
            // Core Cybersecurity Topics (Expanded to 20+)
            { "password", new List<string> { @"\b(password|passwords|passcode|login|credentials)\b" } },
            { "phishing", new List<string> { @"\b(phishing|phish|fake email|suspicious email|spam)\b", @"(click.*link|open.*attachment)" } },
            { "privacy", new List<string> { @"\b(privacy|private|personal data|tracking|cookies)\b" } },
            { "scam", new List<string> { @"\b(scam|scammed|scammer|fraud|fake offer|con artist)\b" } },
            { "malware", new List<string> { @"\b(malware|virus|trojan|worm|infected|hacked)\b", @"(computer.*slow|weird popups)" } },
            { "ransomware", new List<string> { @"\b(ransomware|ransom|encrypt files|locked files)\b", @"(pay.*bitcoin|pay.*money)" } },
            { "mfa", new List<string> { @"\b(mfa|2fa|two factor|multi factor|authenticator)\b" } },
            { "vpn", new List<string> { @"\b(vpn|virtual private network|hide.*ip)\b" } },
            { "firewall", new List<string> { @"\b(firewall|block traffic|network security)\b" } },
            { "publicwifi", new List<string> { @"\b(public wifi|airport wifi|coffee shop wifi|free wifi)\b" } },
            { "updates", new List<string> { @"\b(update|updates|patch|outdated|upgrade)\b" } },
            { "backups", new List<string> { @"\b(backup|backups|back up|restore data|cloud storage)\b" } },
            { "ddos", new List<string> { @"\b(ddos|dos|denial of service|botnet|server crash)\b" } },
            { "socialengineering", new List<string> { @"\b(social engineering|manipulate|impersonate)\b" } },
            { "encryption", new List<string> { @"\b(encryption|encrypt|cryptography|https|ssl)\b" } },
            { "zeroday", new List<string> { @"\b(zero day|0 day|unpatched vulnerability)\b" } },
            { "keylogger", new List<string> { @"\b(keylogger|keystroke|recording my typing)\b" } },
            { "spoofing", new List<string> { @"\b(spoofing|fake caller|fake website)\b" } },
            { "insiderthreat", new List<string> { @"\b(insider threat|disgruntled employee|internal breach)\b" } }
        };

        public List<TopicScore> AnalyzeMulti(string input)
        {
            var scores = new List<TopicScore>();
            if (string.IsNullOrWhiteSpace(input)) return scores;

            string normalizedInput = input.ToLowerInvariant();

            foreach (var topic in topicPatterns)
            {
                int matchCount = 0;
                foreach (var pattern in topic.Value)
                {
                    var matches = Regex.Matches(normalizedInput, pattern, RegexOptions.IgnoreCase);
                    matchCount += matches.Count;
                }

                if (matchCount > 0)
                {
                    scores.Add(new TopicScore { Topic = topic.Key, Score = matchCount });
                }
            }

            return scores.OrderByDescending(s => s.Score).ToList();
        }
    }
}