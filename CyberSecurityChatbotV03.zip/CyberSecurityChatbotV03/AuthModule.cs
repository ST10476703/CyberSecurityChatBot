﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace CyberSecurityChatbotV03
{
    public partial class AuthModule : UserControl
    {
        private DatabaseManager dbManager;

        // This event alerts the MainForm that login was successful
        public event EventHandler OnLoginSuccess;

        public AuthModule(DatabaseManager db)
        {
            InitializeComponent();
            dbManager = db;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user = txtUsername.Text.Trim();
            string pass = txtPassword.Text.Trim();

            if (dbManager.AuthenticateUser(user, pass))
            {
                lblStatus.ForeColor = Color.LimeGreen;
                lblStatus.Text = "Access Granted.";
                OnLoginSuccess?.Invoke(this, EventArgs.Empty); // Unlock the app
            }
            else
            {
                lblStatus.ForeColor = Color.Tomato;
                lblStatus.Text = "Access Denied. Invalid credentials.";
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string user = txtUsername.Text.Trim();
            string pass = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            {
                lblStatus.Text = "Please enter both username and password.";
                return;
            }

            if (dbManager.RegisterUser(user, pass))
            {
                lblStatus.ForeColor = Color.LimeGreen;
                lblStatus.Text = "Registration successful. You may now login.";
            }
            else
            {
                lblStatus.ForeColor = Color.Tomato;
                lblStatus.Text = "Username already exists.";
            }
        }
    }
}
