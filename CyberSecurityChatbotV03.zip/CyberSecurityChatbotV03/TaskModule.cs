﻿using System;
using System.Windows.Forms;

namespace CyberSecurityChatbotV03
{
    public partial class TaskModule : UserControl
    {
        private DatabaseManager dbManager;

        // ===== THIS CONSTRUCTOR FIXES YOUR ERROR =====
        public TaskModule(DatabaseManager db)
        {
            InitializeComponent();
            dbManager = db; // Save the database connection
            this.Load += TaskModule_Load;
        }

        private void TaskModule_Load(object sender, EventArgs e)
        {
            RefreshTaskList();
        }

        // Pulls the latest data from SQLite and updates the DataGrid
        private void RefreshTaskList()
        {
            dgvTasks.DataSource = null; // Clear existing
            dgvTasks.DataSource = dbManager.GetAllTasks();

            // Optional styling: auto-resize columns
            if (dgvTasks.Columns.Count > 0)
            {
                dgvTasks.Columns["Id"].Visible = false; // Hide the database ID
                dgvTasks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
        }

        // ===== CRUD OPERATIONS =====
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Please enter a task title.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var newTask = new TaskItem
            {
                Title = txtTitle.Text,
                Description = txtDescription.Text,
                DueDate = dtpDueDate.Value,
                IsCompleted = false
            };

            dbManager.AddTask(newTask);

            // Clear inputs and refresh table
            txtTitle.Clear();
            txtDescription.Clear();
            RefreshTaskList();
        }

        private void btnComplete_Click(object sender, EventArgs e)
        {
            if (dgvTasks.CurrentRow != null)
            {
                int taskId = Convert.ToInt32(dgvTasks.CurrentRow.Cells["Id"].Value);
                dbManager.UpdateTaskStatus(taskId, true);
                RefreshTaskList();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvTasks.CurrentRow != null)
            {
                int taskId = Convert.ToInt32(dgvTasks.CurrentRow.Cells["Id"].Value);
                dbManager.DeleteTask(taskId);
                RefreshTaskList();
            }
        }
    }
}