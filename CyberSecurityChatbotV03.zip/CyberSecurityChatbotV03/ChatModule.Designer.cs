﻿namespace CyberSecurityChatbotV03
{
    partial class ChatModule
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rtbChat = new RichTextBox();
            txtInput = new TextBox();
            btnSend = new Button();
            btnVoiceToggle = new Button();
            SuspendLayout();
            // 
            // rtbChat
            // 
            rtbChat.BackColor = Color.FromArgb(30, 30, 36);
            rtbChat.Dock = DockStyle.Top;
            rtbChat.ForeColor = Color.FromArgb(0, 255, 163);
            rtbChat.Location = new Point(0, 0);
            rtbChat.Name = "rtbChat";
            rtbChat.ReadOnly = true;
            rtbChat.Size = new Size(957, 306);
            rtbChat.TabIndex = 0;
            rtbChat.Text = "";
            // 
            // txtInput
            // 
            txtInput.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            txtInput.BackColor = Color.FromArgb(45, 45, 53);
            txtInput.BorderStyle = BorderStyle.FixedSingle;
            txtInput.ForeColor = Color.White;
            txtInput.Location = new Point(0, 505);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(125, 27);
            txtInput.TabIndex = 1;
            // 
            // btnSend
            // 
            btnSend.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSend.BackColor = Color.FromArgb(0, 255, 163);
            btnSend.FlatStyle = FlatStyle.Flat;
            btnSend.Location = new Point(863, 503);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(94, 29);
            btnSend.TabIndex = 2;
            btnSend.Text = "Send";
            btnSend.UseVisualStyleBackColor = false;
            btnSend.Click += btnSend_Click;
            // 
            // btnVoiceToggle
            // 
            btnVoiceToggle.BackColor = Color.FromArgb(255, 128, 0);
            btnVoiceToggle.FlatStyle = FlatStyle.Flat;
            btnVoiceToggle.Location = new Point(534, 373);
            btnVoiceToggle.Name = "btnVoiceToggle";
            btnVoiceToggle.Size = new Size(94, 29);
            btnVoiceToggle.TabIndex = 3;
            btnVoiceToggle.Text = "Voice: OFF";
            btnVoiceToggle.UseVisualStyleBackColor = false;
            btnVoiceToggle.Click += btnVoiceToggle_Click;
            // 
            // ChatModule
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnVoiceToggle);
            Controls.Add(btnSend);
            Controls.Add(txtInput);
            Controls.Add(rtbChat);
            Name = "ChatModule";
            Size = new Size(957, 532);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rtbChat;
        private TextBox txtInput;
        private Button btnSend;
        private Button btnVoiceToggle;
    }
}
