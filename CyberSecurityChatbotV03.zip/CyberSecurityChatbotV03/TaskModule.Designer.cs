﻿namespace CyberSecurityChatbotV03
{
    partial class TaskModule
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvTasks = new DataGridView();
            txtTitle = new TextBox();
            txtDescription = new TextBox();
            dtpDueDate = new DateTimePicker();
            btnAdd = new Button();
            btnComplete = new Button();
            btnDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvTasks).BeginInit();
            SuspendLayout();
            // 
            // dgvTasks
            // 
            dgvTasks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTasks.Location = new Point(170, 63);
            dgvTasks.Name = "dgvTasks";
            dgvTasks.RowHeadersWidth = 51;
            dgvTasks.Size = new Size(458, 188);
            dgvTasks.TabIndex = 0;
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(170, 301);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(458, 27);
            txtTitle.TabIndex = 1;
            txtTitle.Text = "Name of task";
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(170, 368);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(458, 27);
            txtDescription.TabIndex = 2;
            txtDescription.Text = "Description";
            // 
            // dtpDueDate
            // 
            dtpDueDate.Location = new Point(0, 30);
            dtpDueDate.Name = "dtpDueDate";
            dtpDueDate.Size = new Size(631, 27);
            dtpDueDate.TabIndex = 3;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(3, 63);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(161, 29);
            btnAdd.TabIndex = 4;
            btnAdd.Text = "Add Task";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnComplete
            // 
            btnComplete.Location = new Point(3, 187);
            btnComplete.Name = "btnComplete";
            btnComplete.Size = new Size(161, 29);
            btnComplete.TabIndex = 5;
            btnComplete.Text = "Mark Complete";
            btnComplete.UseVisualStyleBackColor = true;
            btnComplete.Click += btnComplete_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(3, 222);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(161, 29);
            btnDelete.TabIndex = 6;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // TaskModule
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnDelete);
            Controls.Add(btnComplete);
            Controls.Add(btnAdd);
            Controls.Add(dtpDueDate);
            Controls.Add(txtDescription);
            Controls.Add(txtTitle);
            Controls.Add(dgvTasks);
            Name = "TaskModule";
            Size = new Size(835, 449);
            ((System.ComponentModel.ISupportInitialize)dgvTasks).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvTasks;
        private TextBox txtTitle;
        private TextBox txtDescription;
        private DateTimePicker dtpDueDate;
        private Button btnAdd;
        private Button btnComplete;
        private Button btnDelete;
    }
}
