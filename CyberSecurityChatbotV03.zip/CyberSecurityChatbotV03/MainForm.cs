using System;
using System;
using System.Windows.Forms;

namespace CyberSecurityChatbotV03
{
    public partial class MainForm : Form
    {
        private DatabaseManager dbManager;
        private ReminderSystem reminderSystem;

        public MainForm()
        {
            InitializeComponent();
            dbManager = new DatabaseManager();

            // Hide the sidebar initially
            pnlSidebar.Visible = false;

            // Load the Authentication screen first
            LoadAuthScreen();
        }

        private void LoadAuthScreen()
        {
            var authModule = new AuthModule(dbManager);

            // Subscribe to the success event
            authModule.OnLoginSuccess += (s, args) => UnlockSystem();

            LoadModule(authModule);
        }

        private void UnlockSystem()
        {
            // Show the navigation menu
            pnlSidebar.Visible = true;

            // Start the background systems
            reminderSystem = new ReminderSystem(dbManager);
            reminderSystem.Start();
            this.FormClosing += (sender, e) => reminderSystem?.Stop();

            // Auto-load the Chat Terminal (THIS IS THE LINE WE FIXED)
            LoadModule(new ChatModule(dbManager));
        }

        private void LoadModule(UserControl module)
        {
            pnlContent.Controls.Clear();
            module.Dock = DockStyle.Fill;
            pnlContent.Controls.Add(module);
        }

        private void btnNavChat_Click(object sender, EventArgs e) => LoadModule(new ChatModule(dbManager));
        private void btnNavTasks_Click(object sender, EventArgs e) => LoadModule(new TaskModule(dbManager));
        private void btnNavQuiz_Click(object sender, EventArgs e) => LoadModule(new QuizModule());
        private void btnNavLogs_Click(object sender, EventArgs e) => LoadModule(new LogModule());
    }
}