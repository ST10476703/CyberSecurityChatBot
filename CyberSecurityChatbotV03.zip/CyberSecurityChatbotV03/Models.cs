﻿// ========================= MODELS.CS =========================
using System.Collections.Generic;

/// <summary>
/// Represents a detected topic with a score.
/// </summary>
namespace CyberSecurityChatbotV03
{
    public class UserMemory
    {
        public string UserName { get; set; } = "User";
        public string FavoriteTopic { get; set; } = "";
        public string LastTopic { get; set; } = "";
        public string LastSentiment { get; set; } = "Neutral";
        public string InteractionCount { get; set; } = "" ;



    }

}
