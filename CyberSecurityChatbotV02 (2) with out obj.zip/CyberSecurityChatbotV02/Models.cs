﻿// ========================= MODELS.CS =========================
using System.Collections.Generic;

/// <summary>
/// Represents a detected topic with a score.
/// </summary>
public class TopicScore
{
    public string Topic { get; set; }
    public int Score { get; set; }
}

// Represents an analyzed user request.
// it will be worth it later
public class AnalysisResult
{
    public List<TopicScore> Topics { get; set; } = new List<TopicScore>();
    public string Intent { get; set; } // explain | prevent | risk | unknown
    public int Confidence { get; set; } // 0-100 score so please try
}
