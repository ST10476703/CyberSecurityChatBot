﻿// ========================= INPUT PROCESSOR =========================
using System.Collections.Generic;
using System.Linq;

/// Detects multiple topics using fuzzy contains and returns ranked list.
public class InputProcessor
{
    private Dictionary<string, string[]> map = new Dictionary<string, string[]>
    {
        {"phishing", new[]{"phishing","email scam","fake email","phising"}},
        {"malware", new[]{"malware","virus","trojan"}},
        {"ransomware", new[]{"ransomware","locked files"}},
        {"password", new[]{"password","credentials"}},
        {"2fa", new[]{"2fa","two factor"}},
        {"vpn", new[]{"vpn","private network"}},
        {"encryption", new[]{"encryption","encrypt"}},
        {"firewall", new[]{"firewall"}},
        {"social", new[]{"social engineering"}},
        {"ddos", new[]{"ddos","traffic attack"}},
        {"botnet", new[]{"botnet"}},
        {"spyware", new[]{"spyware"}},
        {"databreach", new[]{"data breach"}},
        {"identity", new[]{"identity theft"}},
        {"zero-day", new[]{"zero day"}}
    };

    
    /// Returns all detected topics ranked by score.
    
    public List<TopicScore> AnalyzeMulti(string input)
    {
        string text = input.ToLower();
        var scores = new List<TopicScore>();

        foreach (var kv in map)
        {
            int score = kv.Value.Count(k => text.Contains(k));
            if (score > 0)
            {
                scores.Add(new TopicScore { Topic = kv.Key, Score = score });
            }
        }

        return scores.OrderByDescending(s => s.Score).ToList();
    }

    // if you dont give a match , alteast theres 25% nyana
    // Computes confidence percentage based on matches.
    // so if we have 4 matches, we can say we're 100% confident. Each match adds 25% confidence.
    public int CalculateConfidence(List<TopicScore> topics)
    {
        if (topics.Count == 0) return 0;
        int total = topics.Sum(t => t.Score);
        return System.Math.Min(100, total * 25);
    }
}