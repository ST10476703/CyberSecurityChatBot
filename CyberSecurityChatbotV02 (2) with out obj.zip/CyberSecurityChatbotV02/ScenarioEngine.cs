﻿// ========================= SCENARIO ENGINE =========================
using System;

// Presents a scenario and evaluates a simple user response.
// trust the process my g
public class ScenarioEngine
{
    public void Run()
    {
        Console.WriteLine("Scenario: You receive an email asking for your bank login. What do you do?");
        Console.Write("Your answer: ");
        string ans = Console.ReadLine().ToLower();

        if (ans.Contains("ignore") || ans.Contains("verify") || ans.Contains("report"))
            Console.WriteLine("Correct. You avoided a phishing attack.");
        else
            Console.WriteLine("Risky action. Always verify and never submit credentials.");
    }
}
