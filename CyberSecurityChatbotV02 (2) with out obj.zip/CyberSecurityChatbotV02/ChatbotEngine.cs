﻿using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Diagnostics;
using System.Media;

public class ChatbotEngine
{
    //this is for safety i got plans to scale "Ntshepe"
    private string userName = "User";
    private InputProcessor processor = new InputProcessor();
    private IntentDetector intentDetector = new IntentDetector();
    private ResponseGenerator responder = new ResponseGenerator();
    private MemoryManager memory = new MemoryManager();
    private ScenarioEngine scenario = new ScenarioEngine();
    private QuizEngine quiz = new QuizEngine();
    private SuggestionEngine suggest = new SuggestionEngine();
    private VoiceService voice = new VoiceService();
    private Logger logger = new Logger();

    
    // Safe startup entry point. Handles audio + UI boot sequence.
    
    public void Start()
    {
        try
        {
            DisplayWelcomeBanner();
            PlayWelcomeAudio();
            CaptureUserName();
            memory.SetUserName(userName);
        }
        catch (Exception ex)
        {
            logger.Log(ex.ToString());
            Console.WriteLine("Startup warning: UI/audio initialization failed.");
        }

        while (true)
        {
            try
            {
                Console.ResetColor();
                Console.Write("You: ");

                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                    continue;

                // Global command routing (safe exit points for subsystem modes ,just incase you over it )
                if (input.Equals("quiz", StringComparison.OrdinalIgnoreCase))
                {
                    quiz.Run();
                    continue;
                }
                if (input.Equals("scenario", StringComparison.OrdinalIgnoreCase))
                {
                    scenario.Run();
                    continue;
                }

                // STEP 1: Intent detection (safe fallback included)
                string intent = "unknown";
                try
                {
                    intent = intentDetector.Detect(input);
                }
                catch
                {
                    logger.Log("Intent detection failed");
                }

                // STEP 2: Topic extraction (null-safe)
                var topics = new List<TopicScore>();
                try
                {
                    topics = processor.AnalyzeMulti(input) ?? new List<TopicScore>();
                }
                catch (Exception ex)
                {
                    logger.Log(ex.ToString());
                }

                // STEP 3: Confidence calculation (safe)
                int confidence = 0;
                try
                {
                    confidence = processor.CalculateConfidence(topics);
                }
                catch
                {
                    confidence = 0;
                }

                // STEP 4: Build analysis object
                AnalysisResult result = new AnalysisResult
                {
                    Topics = topics,
                    Intent = intent,
                    Confidence = confidence
                };

                // STEP 5: Memory update ;)
                try
                {
                    memory.StoreInput(input, result);
                }
                catch
                {
                    logger.Log("Memory store failed");
                }


                // STEP 6: Response generation (isolated fail-safe)
                string response;
                try
                {
                    response = responder.Generate(result, memory);
                }
                catch (Exception ex)
                {
                    logger.Log(ex.ToString());
                    response = "System error in response generation. Please rephrase.";
                }

                // STEP 7: Suggestion engine (non-that important my G , but its here so yeah)
                string suggestion = "";
                try
                {
                    suggestion = suggest.Next(result, memory);
                }
                catch
                {
                    suggestion = "";
                }

                // OUTPUT LAYER
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Bot: " + response);
                Console.WriteLine($"System Confidence Level → {confidence}%");

                if (!string.IsNullOrEmpty(suggestion))
                    Console.WriteLine(suggestion);

                // Voice output (non-blocking safe call)
                try
                {
                    voice.Speak(response);
                }
                catch
                {
                    Console.WriteLine("[Voice disabled]");
                }

                // Scenario prompt logic (controlled UX flow)
                try
                {
                    if (memory.ShouldOfferScenario())
                    {
                        Console.WriteLine("Scenario available. Type 'scenario' to test decision-making.");
                    }
                }
                catch
                {
                    // ignore UX failure
                }
            }
            catch (Exception ex)
            {
                logger.Log(ex.ToString());
                Console.WriteLine("System recovered from runtime error.");
            }
        }
    }

    // ========================= AUDIO + UI BOOT =========================

    private void PlayWelcomeAudio()
    {
        try
        {
            string path = System.IO.Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "cyberaudio.wav"
            );

            System.Media.SoundPlayer player = new System.Media.SoundPlayer(path);
            player.Load();
            player.PlaySync();
        }
        catch (Exception ex)
        {
            Console.WriteLine("[Audio Error] " + ex.Message);
        }
    }
    
    // Prompts user for name and stores it.its worth marks so yeah
    
    private void CaptureUserName()
    {
        Console.Write("Enter your name: ");
        string input = Console.ReadLine();

        if (!string.IsNullOrWhiteSpace(input))
        {
            userName = input;
        }

        Console.WriteLine($"Welcome, {userName}. System ready.\n");
    }
    private void DisplayWelcomeBanner()
    {
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.WriteLine(@"
  ███████╗███████╗ ██████╗██╗   ██╗██████╗ ███████╗
  ██╔════╝██╔════╝██╔════╝██║   ██║██╔══██╗██╔════╝
  ███████╗█████╗  ██║     ██║   ██║██████╔╝█████╗  
  ╚════██║██╔══╝  ██║     ██║   ██║██╔══██╗██╔══╝  
  ███████║███████╗╚██████╗╚██████╔╝██║  ██║███████╗
  ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝

        CYBER SECURITY INTELLIGENCE SYSTEM
");
        Console.ForegroundColor = ConsoleColor.Gray;

        TypeEffect("Initializing secure environment...");
        TypeEffect("System status: ACTIVE");
    }

    private void TypeEffect(string text)
    {
        foreach (char c in text)
        {
            Console.Write(c);
            System.Threading.Thread.Sleep(8);
        }
        Console.WriteLine();
    }
}
