﻿/// ========================= PROGRAM.CS =========================
using System;


// Entry point. Boots the chatbot engine its straight to the point .unlike the rest of the code

class Program
{
    static void Main()
    {
        ChatbotEngine engine = new ChatbotEngine();
        engine.Start();
    }
}