﻿// ========================= RESPONSE GENERATOR =========================
using System.Text;


/// Builds responses for multiple topics with adaptive depth and anti-repetition.
/// Structure: Definition + Risks + Prevention. Intention was to give as much as possible

public class ResponseGenerator
{
    private System.Random rng = new System.Random();


    public string Generate(AnalysisResult result, MemoryManager memory)
    {
        if (result.Topics.Count == 0)
        {
            return "I don’t know enough about that specific case. I recommend focusing on topics like phishing, malware, or passwords. Can you clarify your question?";
        }
       
        StringBuilder sb = new StringBuilder();
        string name = memory.GetUserName();
        
        foreach (var t in result.Topics)
        {
            int level = memory.GetInteractionLevel(t.Topic);

            // Anti-repetition: rotate phrasing by level + random .i know.
            string def = GetDefinition(t.Topic, level);
            string risks = GetRisks(t.Topic, level);
            string prev = GetPrevention(t.Topic, level);

            sb.AppendLine(def);
            sb.AppendLine();
            sb.AppendLine("Risks:");
            sb.AppendLine(risks);
            sb.AppendLine();
            sb.AppendLine("Prevention:");
            sb.AppendLine(prev);
            sb.AppendLine();

            if (level == 1)
            {
                sb.AppendLine("Do you want to go deeper into this topic?");
                sb.AppendLine();
            }
        }

        return $"Alright {name}, here’s what you need to know:\n\n" + sb.ToString();
    }

    private string GetDefinition(string topic, int level)
{
    switch (topic)
    {
        case "phishing": return level == 1 ? "Phishing is a social engineering attack using fake messages to steal data." : "Phishing campaigns use spoofed domains and social cues to extract credentials.";
        case "malware": return level == 1 ? "Malware is software designed to damage or exploit systems." : "Malware includes trojans, worms, and fileless attacks that exploit system vulnerabilities.";
        case "password": return level == 1 ? "Passwords protect access to accounts." : "Password security relies on entropy, uniqueness, and proper storage practices.";
        default: return $"{topic} is a cybersecurity concept relevant to system protection.";
    }
}

private string GetRisks(string topic, int level)
{
    switch (topic)
    {
        case "phishing": return "- Credential theft\n- Financial loss\n- Account takeover";
        case "malware": return "- Data corruption\n- System compromise\n- Unauthorized control";
        case "password": return "- Account breaches\n- Identity theft\n- Data leaks";
        default: return "- Security exposure\n- Data risk";
    }
}

private string GetPrevention(string topic, int level)
{
    switch (topic)
    {
        case "phishing": return "1. Verify sender\n2. Hover links\n3. Avoid attachments\n4. Enable 2FA";
        case "malware": return "1. Avoid unknown downloads\n2. Use antivirus\n3. Update systems\n4. Sandbox suspicious files";
        case "password": return "1. Use long unique passwords\n2. Use a manager\n3. Enable 2FA\n4. Avoid reuse";
        default: return "1. Follow best practices\n2. Stay updated\n3. Use layered security";
    }
}
}