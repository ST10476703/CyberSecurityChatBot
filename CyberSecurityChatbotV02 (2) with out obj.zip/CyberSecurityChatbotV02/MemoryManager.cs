﻿// ========================= MEMORY MANAGER =========================
using System.Collections.Generic;

// Tracks topic frequency, last responses, and simple session state.
public class MemoryManager
{
    private Dictionary<string, int> topicCount = new Dictionary<string, int>();
    private int turns = 0;

    public void StoreInput(string input, AnalysisResult result)
    {
        turns++;
    }

    public int GetInteractionLevel(string topic)
    {
        if (!topicCount.ContainsKey(topic)) topicCount[topic] = 0;
        topicCount[topic]++;
        return topicCount[topic];
    }

    public bool ShouldOfferScenario()
    {
        return turns % 3 == 0;
    }
    private string userName;

    public void SetUserName(string name)
    {
        userName = name;
    }

    public string GetUserName()
    {
        return userName ?? "User";
    }
}
