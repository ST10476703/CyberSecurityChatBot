﻿// ========================= INTENT DETECTOR =========================
using System.Linq;

/// shes a beauty , i know 
/// Classifies user intent: explain | prevent | risk | unknown

public class IntentDetector
{
    private string[] explain = { "what is", "define", "explain" };
    private string[] prevent = { "how to", "prevent", "avoid", "protect" };
    private string[] risk = { "why", "risk", "danger", "impact" };

    public string Detect(string input)
    {
        string text = input.ToLower();

        if (explain.Any(k => text.Contains(k))) return "explain";
        if (prevent.Any(k => text.Contains(k))) return "prevent";
        if (risk.Any(k => text.Contains(k))) return "risk";

        return "unknown";
    }
}
