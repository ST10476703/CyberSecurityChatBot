﻿// ========================= MEMORY MANAGER =========================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

public class MemoryManager
{
    // ===== CORE MEMORY =====
    private static Dictionary<string, int> topicInteractions = new Dictionary<string, int>();
    private List<string> topicHistory = new List<string>();
    private List<string> usedResponses = new List<string>();

    private int interactionCount = 0;
    private string userName = "User";
    private string filePath = "memory.txt";
    public string LastTopic { get; private set; }
    public string FavoriteTopic { get; private set; }
    public string Sentiment { get; private set; }

    // ===== BASIC MEMORY METHODS =====
     public void IncrementTopicInteraction(string topic)
     {
        if (!topicInteractions.ContainsKey(topic))
        {
            topicInteractions[topic] = 0;
        }

        topicInteractions[topic]++;
     }
       public int GetInteractionLevel(string topic)
      {
        if (!topicInteractions.ContainsKey(topic))
        {
            return 1;
        }

        return topicInteractions[topic];
      }
    
    public void SetUserName(string name)
    {
        this.userName = name;
    }
    public string GetUserName() 
    { 
        return userName;
    }
    public void SetLastTopic(string topic)
    {
        LastTopic = topic;

        if (!string.IsNullOrWhiteSpace(topic))
        {
            topicHistory.Add(topic);
        }
    }

    public void SetFavoriteTopic(string topic)
    {
        FavoriteTopic = topic;
    }

    public void SetSentiment(string sentiment)
    {
        Sentiment = sentiment;
    }

    public void IncrementInteraction()
    {
        interactionCount++;
    }

    public int GetInteractionCount()
    {
        return interactionCount;
    }

    // ===== TOPIC HISTORY =====

    public bool HasSeenTopic(string topic)
    {
        return topicHistory.Contains(topic);
    }

    public List<string> GetTopicHistory()
    {
        return topicHistory;
    }

    // ===== ANTI-REPETITION =====

    public bool WasUsed(string response)
    {
        return usedResponses.Contains(response);
    }

    public void StoreResponse(string response)
    {
        usedResponses.Add(response);

        if (usedResponses.Count > 50)
            usedResponses.RemoveAt(0);
    }

    // ===== PERSISTENCE (ACROSS SESSIONS) =====
    public void AddTopic(string topic)
    {
        topicHistory.Add(topic);
    }
    public void Save()
    {
        File.WriteAllLines(filePath, new[]
        {
            LastTopic ?? "",
            FavoriteTopic ?? "",
            Sentiment ?? "",
            string.Join(",", topicHistory)
        });
    }

    public void Load()
    {
        if (!File.Exists(filePath))
            return;

        string[] lines = File.ReadAllLines(filePath);

        if (lines.Length >= 1) LastTopic = lines[0];
        if (lines.Length >= 2) FavoriteTopic = lines[1];
        if (lines.Length >= 3) Sentiment = lines[2];

        if (lines.Length >= 4 && !string.IsNullOrWhiteSpace(lines[3]))
        {
            topicHistory = new List<string>(lines[3].Split(','));
        }
    }
}