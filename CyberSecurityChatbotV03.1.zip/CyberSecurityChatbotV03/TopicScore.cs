﻿public class TopicScore
{
    public string Topic { get; set; }

    public int Score { get; set; }
}