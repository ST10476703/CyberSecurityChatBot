using System;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CyberSecurityChatbotV03
{
    public partial class MainForm : Form
    {
        // ===== GLOBAL FIELDS (TOP ONLY) =====
        private ChatbotEngine bot = new ChatbotEngine();

        private ProfileManager profileManager = new ProfileManager();
        private UserProfile profile;

        private bool waitingForUserName = false;
        private bool waitingForBotName = false;
        private MemoryManager memory = new MemoryManager();
        private bool isNewUser = false;

        // ===== CONSTRUCTOR =====
        public MainForm()
        {
            InitializeComponent();
            this.Load += MainForm_Load;
        }

        // ===== FORM LOAD (STARTUP LOGIC) =====
        private void MainForm_Load(object sender, EventArgs e)
        {
            memory.Load();
            profile = profileManager.Load();

            isNewUser = (profile == null || string.IsNullOrWhiteSpace(profile.Name));

            if (isNewUser)
            {
                rtbChat.AppendText("Welcome to Cebre chatbot System\n");
                rtbChat.AppendText("What is your name?\n");

                waitingForUserName = true;
            }
            else
            {
                rtbChat.AppendText($"Welcome back {profile.Name}\n");
                rtbChat.AppendText($"I am {profile.BotName}\n");
                rtbChat.AppendText("How can I help you?\n");
            }
        }

        // ===== SEND BUTTON =====
        private void btnSend_Click(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();

            if (string.IsNullOrEmpty(input))
                return;

            rtbChat.AppendText("You: " + input + "\n");

            // ===== FIRST TIME SETUP FLOW =====
            if (isNewUser)
            {
                if (waitingForUserName)
                {
                    profile = new UserProfile();
                    profile.Name = input;

                    waitingForUserName = false;
                    waitingForBotName = true;

                    rtbChat.AppendText($"Nice to meet you {profile.Name}\n");
                    rtbChat.AppendText("What would you like to call me?\n");

                    txtInput.Clear();
                    return;
                } 

                if (waitingForBotName)
                {
                    profile.BotName = input;

                    profileManager.Save(profile);

                    waitingForBotName = false;

                    rtbChat.AppendText($"Perfect. I am now {profile.BotName}\n");
                    rtbChat.AppendText("Setup complete. Let's begin.\n");

                    txtInput.Clear();
                    return;
                }
            }

            // ===== NORMAL CHATBOT FLOW =====
            string response = bot.ProcessInput(input);

            rtbChat.AppendText("Bot: " + response + "\n\n");

            txtInput.Clear();
        }
    }
}


