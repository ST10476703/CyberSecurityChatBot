﻿public class UserProfile
{
    public string Name { get; set; }
    public string BotName { get; set; }
}