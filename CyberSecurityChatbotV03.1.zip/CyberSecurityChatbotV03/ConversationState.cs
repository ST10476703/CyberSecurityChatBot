﻿using System.Collections.Generic;

public class ConversationState
{
    public string CurrentTopic { get; set; }
    public string PreviousTopic { get; set; }
    public string CurrentMood { get; set; }
    public string LastBotResponse { get; set; }

    public int TopicDepth { get; set; }

    public List<string> RecentResponses { get; set; }
        = new List<string>();
}