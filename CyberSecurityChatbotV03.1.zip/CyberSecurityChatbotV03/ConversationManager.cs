﻿using System;


  public class ConversationManager
  {
      public bool IsFollowUp(string input)
      {
        string text = input.ToLower();

        return text.Contains("more") ||
               text.Contains("again") ||
               text.Contains("explain") ||
               text.Contains("why") ||
               text.Contains("how") ||
               text.Contains("yes") ||
               text.Contains("deep")||
               text.Contains("elaborate") ||
               text.Contains("continue") ||
               text.Contains("go") ||
               text.Contains("tell me");
      }
}
