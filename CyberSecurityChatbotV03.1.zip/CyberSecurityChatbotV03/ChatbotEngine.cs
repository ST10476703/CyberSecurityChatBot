﻿using CyberSecurityChatbotV02;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Media;

public class ChatbotEngine
{
    //this is for safety i got plans to scale "Ntshepe"
    private string userName = "User";
    private InputProcessor processor = new InputProcessor();
    private IntentDetector intentDetector = new IntentDetector();
    private ResponseGenerator responder = new ResponseGenerator();
    private MemoryManager memory = new MemoryManager();
    private ScenarioEngine scenario = new ScenarioEngine();
    private QuizEngine quiz = new QuizEngine();
    private SuggestionEngine suggest = new SuggestionEngine();
    private VoiceService voice = new VoiceService();
    private Logger logger = new Logger();
    //new
    private SentimentAnalyzer sentimentAnalyzer = new SentimentAnalyzer();
    private ConversationManager conversationManager = new ConversationManager();
    private ConversationState state = new ConversationState();
    // Safe startup entry point. Handles audio + UI boot sequence.
    public ChatbotEngine()
    {
        memory.Load();
    }
    public string ProcessInput(string input)
    {
        if (string.IsNullOrWhiteSpace(input))
            return "Please enter a message.";

        string sentiment = sentimentAnalyzer.DetectSentiment(input);
        memory.SetSentiment(sentiment);
        state.CurrentMood = sentiment;

        memory.IncrementInteraction();

        string lowered = input.ToLower();

        if (
            lowered.Contains("privacy") &&
            (
                lowered.Contains("like") ||
                lowered.Contains("love") ||
                lowered.Contains("interested")
            )
        )
        {
            memory.SetFavoriteTopic("privacy");
            memory.Save();

            return "Great! I'll remember that you're interested in privacy.";
        }
        var topics = processor.AnalyzeMulti(input) ?? new List<TopicScore>();
        if (conversationManager.IsFollowUp(input))
        {
            string LastTopic = memory.LastTopic;

            if (!string.IsNullOrEmpty(LastTopic))
            {
                memory.IncrementTopicInteraction(LastTopic);
                memory.Save();

                var result = new AnalysisResult
                {
                    Topics = new List<TopicScore>
            {
                new TopicScore { Topic = LastTopic, Score = 1 }
            },
                    Intent = "followup",
                    Confidence = 100
                };

                return responder.Generate(result, memory);
            }
        }
        

        if (topics.Count > 0)
        {
            memory.SetLastTopic(topics[0].Topic);
            memory.IncrementTopicInteraction(topics[0].Topic);
            memory.AddTopic(topics[0].Topic);
            memory.Save();

            AnalysisResult result = new AnalysisResult
            {
                Topics = topics,
                Intent = "normal",
                Confidence = processor.CalculateConfidence(topics)
            };

            string response = responder.Generate(result, memory);

            response = sentimentAnalyzer.ApplySentiment(response, sentiment);

            state.LastBotResponse = response;

            return response;
        }

        return "I'm not sure I understand. Can you try rephrasing?";
    }
    
    

    

    // ========================= AUDIO + UI BOOT =========================

    private void PlayWelcomeAudio()
    {
        try
        {
            string path = System.IO.Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "cyberaudio.wav"
            );

            System.Media.SoundPlayer player = new System.Media.SoundPlayer(path);
            player.Load();
            player.PlaySync();
        }
        catch (Exception ex)
        {
            Console.WriteLine("[Audio Error] " + ex.Message);
        }
    }

    // Prompts user for name and stores it.its worth marks so yeah

    private void CaptureUserName()
    {
        Console.Write("Enter your name: ");
        string input = Console.ReadLine();

        if (!string.IsNullOrWhiteSpace(input))
        {
            userName = input;
        }

        Console.WriteLine($"Welcome, {userName}. System ready.\n");
    }
    private void DisplayWelcomeBanner()
    {
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.WriteLine(@"
  ███████╗███████╗ ██████╗██╗   ██╗██████╗ ███████╗
  ██╔════╝██╔════╝██╔════╝██║   ██║██╔══██╗██╔════╝
  ███████╗█████╗  ██║     ██║   ██║██████╔╝█████╗  
  ╚════██║██╔══╝  ██║     ██║   ██║██╔══██╗██╔══╝  
  ███████║███████╗╚██████╗╚██████╔╝██║  ██║███████╗
  ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝

        CYBER SECURITY INTELLIGENCE SYSTEM
");
        Console.ForegroundColor = ConsoleColor.Gray;

        TypeEffect("Initializing secure environment...");
        TypeEffect("System status: ACTIVE");
    }

    private void TypeEffect(string text)
    {
        foreach (char c in text)
        {
            Console.Write(c);
            System.Threading.Thread.Sleep(8);
        }
        Console.WriteLine();
    }

}
