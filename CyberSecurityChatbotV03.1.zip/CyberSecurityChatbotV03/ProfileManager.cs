﻿public class ProfileManager
{
    private string path = "profile.txt";

    public void Save(UserProfile p)
    {
        File.WriteAllLines(path, new[]
        {
            p.Name,
            p.BotName
        });
    }

    public UserProfile Load()
    {
        if (!File.Exists(path))
            return null;

        var lines = File.ReadAllLines(path);

        if (lines.Length < 2)
            return null;

        return new UserProfile
        {
            Name = lines[0],
            BotName = lines[1]
        };
    }
}