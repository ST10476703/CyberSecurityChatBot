﻿// ========================= INPUT PROCESSOR =========================
using CyberSecurityChatbotV03;
using System.Collections.Generic;
using System.Linq;

/// Detects multiple topics using fuzzy contains and returns ranked list.
public class InputProcessor
{
    
    private Dictionary<string, string[]> map = new Dictionary<string, string[]>
 {
    {
        "password",
        new[]
        {
            "password",
            "passwords",
            "login",
            "log in",
            "credential",
            "credentials",
            "account security",
            "sign in"
        }
    },

    {
        "phishing",
        new[]
        {
            "phishing",
            "fake email",
            "email scam",
            "suspicious email",
            "fake website",
            "fake login",
            "phising",
            "phish"
        }
    },

    {
        "privacy",
        new[]
        {
            "privacy",
            "personal data",
            "tracking",
            "private information",
            "data collection",
            "online privacy",
            "privacy settings"
        }
    },

    {
        "scam",
        new[]
        {
            "scam",
            "scammed",
            "fraud",
            "fake offer",
            "fake giveaway",
            "money scam",
            "online scam",
            "con artist"
        }
    },

    {
        "malware",
        new[]
        {
            "malware",
            "virus",
            "trojan",
            "worm",
            "infected",
            "computer virus",
            "ransomware"
        }
    }
 };

    /// Returns all detected topics ranked by score.

    public List<TopicScore> AnalyzeMulti(string input)
    {
        string text = input.ToLower();
        var scores = new List<TopicScore>();

        foreach (var kv in map)
        {
            int score = kv.Value.Count(k => text.Contains(k));
            if (score > 0)
            {
                scores.Add(new TopicScore { Topic = kv.Key, Score = score });
            }
        }

        return scores.OrderByDescending(s => s.Score).ToList();
    }

    // if you dont give a match , alteast theres 25% nyana
    // Computes confidence percentage based on matches.
    // so if we have 4 matches, we can say we're 100% confident. Each match adds 25% confidence.
    public int CalculateConfidence(List<TopicScore> topics)
    {
        if (topics.Count == 0) return 0;
        int total = topics.Sum(t => t.Score);
        return System.Math.Min(100, total * 25);
    }
}