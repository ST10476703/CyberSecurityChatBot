// ========================= PROGRAM.CS =========================
// Entry point. Boots the chatbot engine — console-style startup that runs ChatbotEngine.
using CyberSecurityChatbotV03;
using System;
using System.Windows.Forms;

namespace CyberSecurityChatBotGUI
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
    }
}
