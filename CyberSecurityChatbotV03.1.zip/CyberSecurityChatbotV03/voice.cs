﻿// ========================= VOICE SERVICE =========================
using System.Speech.Synthesis;

// took me days to figure this mess out, but now we have TTS for responses.
// Handles TTS for responses.
// i wasnt paying attention to this part but i guess its important for accessibility and engagement.
public class VoiceService
{
    private SpeechSynthesizer synth = new SpeechSynthesizer();

    public void Speak(string text)
    {
        synth.SpeakAsync(text);
    }
}