﻿// ========================= SCENARIO ENGINE =========================

// i am the only one who can suggest ,but leave some comments on the rubric for me
// Suggests next best topic based on current context.
// we know people leave dry text , this way its better
public class ScenarioEngine
{
    private Random random = new Random();

    private string[] scenarios =
    {
        "You receive an email claiming your bank account is locked and asking you to click a link.",
        "A stranger sends you a USB drive and asks you to open a file.",
        "You receive a text message saying you've won a prize and need to provide personal details."
    };

    public string Run()
    {
        return scenarios[random.Next(scenarios.Length)];
    }
}