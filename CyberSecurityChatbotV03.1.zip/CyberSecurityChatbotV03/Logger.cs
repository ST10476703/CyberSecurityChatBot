﻿// ========================= LOGGER =========================
using System.IO;
// File logger.
// its important for whats to come, and also for debugging.
public class Logger
{
    public void Log(string message)
    {
        File.AppendAllText("log.txt", message + "\n");
    }
}
// ========================= END OF LOGGER ========================= ;)