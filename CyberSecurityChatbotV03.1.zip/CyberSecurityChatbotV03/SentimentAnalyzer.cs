﻿using System;

public class SentimentAnalyzer
{
    public string DetectSentiment(string input)
    {
        input = input.ToLower();

        if (input.Contains("worried") || input.Contains("scared") || input.Contains("nervous"))
        {
            return "Worried";
        }

        if (input.Contains("confused") || input.Contains("don't understand"))
        {
            return "Confused";
        }

        if (input.Contains("frustrated") || input.Contains("annoyed"))
        {
            return "Frustrated";
        }

        if (input.Contains("curious") || input.Contains("interested"))
        {
            return "Curious";
        }

        return "Neutral";
    }

    public string ApplySentiment(string response, string sentiment)
    {
        switch (sentiment)
        {
            case "Worried":
                return "It's understandable to feel worried about cybersecurity threats. "
                       + response;

            case "Confused":
                return "No problem. Let me simplify it for you. "
                       + response;

            case "Frustrated":
                return "Cybersecurity can feel overwhelming at first. "
                       + response;

            case "Curious":
                return "Great curiosity is important in cybersecurity. "
                       + response;

            default:
                return response;
        }
    }
}