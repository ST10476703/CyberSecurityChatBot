﻿using System.Text;

using static System.Windows.Forms.AxHost;

// ========================= RESPONSE GENERATOR =========================
using System.Text;


/// Builds responses for multiple topics with adaptive depth and anti-repetition.
/// Structure: Definition + Risks + Prevention. Intention was to give as much as possible

public class ResponseGenerator
{
    private System.Random rng = new System.Random();
    private Random random = new Random();
    //new
    private Dictionary<string, List<string>> topicResponses =
        new Dictionary<string, List<string>>()
   {
     {
    "password",
    new List<string>()
       {
        "Use strong unique passwords for every account.",
        "Avoid reusing passwords across different websites.",
        "Enable multi-factor authentication whenever possible.",
        "Long passwords with symbols are harder to crack.",
        "A password manager can help generate secure passwords.",
        "Avoid using personal information in your passwords.",
        "Change passwords immediately if a breach is suspected.",
        "Use passphrases made of multiple random words for better security."
       }
     },

     {
    "phishing",
    new List<string>()
       {
        "Never click suspicious links in emails or messages.",
        "Verify email senders carefully before responding.",
        "Banks rarely ask for passwords through email.",
        "Watch for urgent language designed to pressure you.",
        "Hover over links before clicking to inspect the destination.",
        "Be cautious of unexpected attachments.",
        "Check website URLs carefully before entering credentials.",
        "Enable multi-factor authentication to reduce phishing damage."
       }
     },
     {
    "privacy",
    new List<string>()
       {
        "Review your privacy settings regularly.",
        "Avoid oversharing personal information online.",
        "Use secure browsers and privacy-focused tools.",
        "Limit app permissions on your devices.",
        "Check which apps have access to your location data.",
        "Use strong passwords to protect private accounts.",
        "Be cautious when posting personal details on social media.",
        "Regularly review connected devices and account activity."
       }
     },
     {
     "scam",
     new List<string>()
       {
        "Be suspicious of offers that seem too good to be true.",
        "Never send money to someone you have not verified.",
        "Scammers often create urgency to pressure victims.",
        "Verify identities before sharing sensitive information.",
        "Avoid clicking links from unknown sources.",
        "Research companies before making online payments.",
        "Watch out for fake giveaways and investment opportunities.",
        "If something feels suspicious, pause and investigate first."
       }
     },
      {
    "malware",
    new List<string>()
       {
        "Keep your operating system and software updated.",
        "Avoid downloading files from untrusted sources.",
        "Use reputable antivirus or endpoint protection software.",
        "Be careful when opening email attachments.",
        "Regularly back up important files.",
        "Scan removable drives before opening them.",
        "Malware can steal information or damage systems.",
        "Use a firewall to help block malicious traffic."
       }
      }
   };

    public string GetRandomTopicResponse(string topic, ConversationState state)
    {
        if (!topicResponses.ContainsKey(topic))
        {
            return "I'm not sure I understand. Can you rephrase?";
        }

        List<string> responses = topicResponses[topic];

        List<string> filtered =
            responses
            .Where(r => !state.RecentResponses.Contains(r))
            .ToList();

        if (filtered.Count == 0)
        {
            filtered = responses;
        }

        string selected =
            filtered[random.Next(filtered.Count)];

        return selected;
    }
    private Dictionary<string, List<string>> randomResponses =
    new Dictionary<string, List<string>>
    {
    };
    //old
    public string GetRandomTopicResponse(string topic)
    {
        topic = topic.ToLower();

        if (randomResponses.ContainsKey(topic))
        {
            List<string> responses = randomResponses[topic];

            return responses[random.Next(responses.Count)];
        }

        return "I do not have information on that topic yet.";
    }


    public string Generate(AnalysisResult result, MemoryManager memory)
    {
        if (result.Topics.Count == 0)
        {
            return "I don’t know enough about that specific case. I recommend focusing on topics like phishing, malware, or passwords. Can you clarify your question?";
        }

        StringBuilder sb = new StringBuilder();
        string name = memory.GetUserName();

        foreach (var t in result.Topics)
        {
            int level = memory.GetInteractionLevel(t.Topic);
            

            // Anti-repetition: rotate phrasing by level + random .i know.
            string def = GetDefinition(t.Topic, level);
            string risks = GetRisks(t.Topic, level);
            string prev = GetPrevention(t.Topic, level);

            sb.AppendLine(def);
            sb.AppendLine();
            sb.AppendLine("Risks:");
            sb.AppendLine(risks);
            sb.AppendLine();
            sb.AppendLine("Prevention:");
            sb.AppendLine(prev);
            sb.AppendLine();

            if (level == 1)
            {
                sb.AppendLine("Do you want to go deeper into this topic?");
                sb.AppendLine();
            }
        }

        return $"Alright {name}, here’s what you need to know:\n\n" + sb.ToString();
    }
    public string ApplySentiment(string response, string sentiment)
    {
        switch (sentiment)
        {
            case "Worried":
                return "I understand your concern. " + response;

            case "Frustrated":
                return "Cybersecurity can feel overwhelming sometimes. " + response;

            case "Curious":
                return "That is a great thing to learn about. " + response;

            default:
                return response;
        }
    }



    private string GetDefinition(string topic, int level)
    {
        switch (topic)
        {
            case "password":

                if (level == 1)
                    return "Passwords protect access to accounts.";

                if (level == 2)
                    return "Strong passwords resist brute-force attacks better than simple passwords.";

                if (level == 3)
                    return "Password entropy measures how difficult a password is to crack.";

                return "Modern security combines passwords with multi-factor authentication and credential monitoring.";

            case "phishing":

                if (level == 1)
                    return "Phishing is an attack that tricks users into revealing information.";

                if (level == 2)
                    return "Phishing often uses fake emails pretending to be trusted organizations.";

                if (level == 3)
                    return "Attackers frequently clone login pages to steal credentials.";

                return "Advanced phishing campaigns use personalization and social engineering techniques.";

            case "malware":

                if (level == 1)
                    return "Malware is malicious software designed to harm systems.";

                if (level == 2)
                    return "Common malware includes viruses, trojans, worms and spyware.";

                if (level == 3)
                    return "Malware often exploits vulnerabilities to gain persistence.";

                return "Modern malware may operate filelessly and evade traditional antivirus tools.";
        }

        return $"{topic} is a cybersecurity topic.";
    }
    private string GetRisks(string topic, int level)
    {
        switch (topic)
        {
            case "password":

                if (level == 1)
                    return "- Weak passwords can be guessed";

                if (level == 2)
                    return "- Brute force attacks\n- Credential stuffing";

                if (level == 3)
                    return "- Password reuse across services";

                return "- Large-scale account compromise";

            case "phishing":

                if (level == 1)
                    return "- Stolen credentials";

                if (level == 2)
                    return "- Financial fraud";

                if (level == 3)
                    return "- Identity theft";

                return "- Business email compromise";

            case "malware":

                if (level == 1)
                    return "- Device infection";

                if (level == 2)
                    return "- Data corruption";

                if (level == 3)
                    return "- Unauthorized system access";

                return "- Enterprise-wide compromise";
        }

        return "- Security risks exist";
    }

    private string GetPrevention(string topic, int level)
    {
        switch (topic)
        {
            case "password":

                if (level == 1)
                    return "Use passwords longer than 12 characters.";

                if (level == 2)
                    return "Use a password manager.";

                if (level == 3)
                    return "Never reuse passwords across services.";

                return "Enable MFA on every important account.";

            case "phishing":

                if (level == 1)
                    return "Verify email senders.";

                if (level == 2)
                    return "Hover over links before clicking.";

                if (level == 3)
                    return "Verify URLs carefully.";

                return "Use MFA to reduce phishing damage.";

            case "malware":

                if (level == 1)
                    return "Avoid suspicious downloads.";

                if (level == 2)
                    return "Keep software updated.";

                if (level == 3)
                    return "Use antivirus protection.";

                return "Use sandboxing and application control.";
        }

        return "Follow cybersecurity best practices.";
    }
    //new
    public string GetFollowUpResponse(
    string topic,
    int depth)
        
    {
        if (topic == "phishing")
        {
            switch (depth)
            {
                case 1:
                    return "Phishing attacks usually pretend to be trusted organizations.";

                case 2:
                    return "Attackers often use fake login pages to steal credentials.";

                case 3:
                    return "Always verify website URLs before entering passwords.";

                default:
                    return "Enable MFA to reduce phishing risks.";
            }
        }

        if (topic == "privacy")
        {
            switch (depth)
            {
                case 1:
                    return "Privacy involves controlling who can access your personal information.";

                case 2:
                    return "Review privacy settings on social media and online accounts regularly.";

                case 3:
                    return "Companies often collect metadata, so always check data-sharing permissions.";

                default:
                    return "Using privacy-focused browsers and tools can reduce online tracking.";
            }
        }
         if (topic == "scam")
        {
            switch (depth)
            {
                case 1:
                    return "Online scams often rely on emotional manipulation and urgency.";

                case 2:
                    return "Scammers may impersonate trusted organizations or people you know.";

                case 3:
                    return "Always verify requests for money or sensitive information independently.";

                default:
                    return "When in doubt, stop communicating and investigate before taking action.";
            }
        }
         if (topic == "malware")
        {
            switch (depth)
            {
                case 1:
                    return "Malware is malicious software designed to harm or exploit systems.";

                case 2:
                    return "Common malware types include viruses, worms, trojans, and ransomware.";

                case 3:
                    return "Many malware infections begin through phishing emails or unsafe downloads.";

                default:
                    return "Keeping software updated significantly reduces malware risk.";
            }
        }

        if (topic == "password")
        {
            switch (depth)
            {
                case 1:
                    return "Weak passwords are vulnerable to brute force attacks.";

                case 2:
                    return "Password managers help generate secure passwords.";

                case 3:
                    return "Avoid storing passwords in plain text files.";

                default:
                    return "Multi-factor authentication strengthens account security.";
            }
        }
        if (topic == "hashing")
        {
            switch (depth)
            {
                case 1:
                    return "Is a form of 1 way encryption.";

                case 2:
                    return "unlike other encryption standards it canot be reversed.";

                

                default:
                    return "Hashing is typically used by messages.";
            }
        
        
        }
        
        return "Can you clarify what you'd like to know more about?";
    }
}