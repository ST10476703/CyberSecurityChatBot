﻿using System.Collections.Generic;

public class AnalysisResult
{
    public List<TopicScore> Topics { get; set; }
        = new List<TopicScore>();

    public string Intent { get; set; }

    public int Confidence { get; set; }
}