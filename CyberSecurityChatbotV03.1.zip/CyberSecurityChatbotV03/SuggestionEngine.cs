﻿// ========================= SUGGESTION ENGINE =========================
using System.Linq;

// i am the only one who can suggest ,but leave some comments on the rubric for me
// Suggests next best topic based on current context.
// we know people leave dry text , this way its better
public class SuggestionEngine
{
    public string Next(AnalysisResult result, MemoryManager memory)
    {
        if (result.Topics.Count == 0) return string.Empty;
        string t = result.Topics.First().Topic;
        return $"I recommend learning about related areas like security basics or {t}. Want to continue?";
    }
}
