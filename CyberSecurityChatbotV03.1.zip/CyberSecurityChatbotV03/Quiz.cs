﻿// ========================= QUIZ ENGINE =========================
using System;

// stay tuned for more like and subscribe.oh and if you fail its only 1 question but also reflect on your self
/// Simple quiz mode with scoring.
// it's basic but it serves its purpose for now, and also gives a nice break from the more intense stuff.
public class QuizEngine
{
    public void Run()
    {
        int score = 0;
        Console.WriteLine("Quiz Mode:\n1) What is phishing?\nA) Safe email\nB) Scam\nC) Firewall");
        var a = Console.ReadLine();
        if (a.Equals("B", StringComparison.OrdinalIgnoreCase)) score++;
        Console.WriteLine($"Score: {score}/1");
    }
}