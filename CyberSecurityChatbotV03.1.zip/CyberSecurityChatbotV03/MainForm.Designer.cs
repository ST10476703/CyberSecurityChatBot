﻿namespace CyberSecurityChatbotV03
{
    partial class MainForm
    {
        
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            rtbChat = new RichTextBox();
            txtInput = new TextBox();
            btnSend = new Button();
            btnVoice = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            iblAscii = new Label();
            richTextBox1 = new RichTextBox();
            SuspendLayout();
            // 
            // rtbChat
            // 
            rtbChat.BackColor = Color.MidnightBlue;
            rtbChat.BorderStyle = BorderStyle.None;
            rtbChat.Font = new Font("Consolas", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rtbChat.ForeColor = Color.Lime;
            rtbChat.Location = new Point(-5, 150);
            rtbChat.Name = "rtbChat";
            rtbChat.ReadOnly = true;
            rtbChat.Size = new Size(887, 287);
            rtbChat.TabIndex = 0;
            rtbChat.Text = "";
          //  rtbChat.TextChanged += rtbChat_TextChanged;
            // 
            // txtInput
            // 
            txtInput.BackColor = Color.Lime;
            txtInput.Location = new Point(606, 461);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(234, 27);
            txtInput.TabIndex = 1;
            // 
            // btnSend
            // 
            btnSend.BackColor = Color.Lime;
            btnSend.FlatStyle = FlatStyle.Flat;
            btnSend.Location = new Point(740, 511);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(100, 30);
            btnSend.TabIndex = 2;
            btnSend.Text = "Send";
            btnSend.UseVisualStyleBackColor = false;
            btnSend.Click += btnSend_Click;
            // 
            // btnVoice
            // 
            btnVoice.BackColor = Color.Lime;
            btnVoice.Location = new Point(606, 511);
            btnVoice.Name = "btnVoice";
            btnVoice.Size = new Size(104, 30);
            btnVoice.TabIndex = 3;
            btnVoice.Text = "Voice";
            btnVoice.UseVisualStyleBackColor = false;
            // 
            // iblAscii
            // 
            iblAscii.BackColor = Color.MidnightBlue;
            iblAscii.ForeColor = Color.Lime;
            iblAscii.Location = new Point(-5, 440);
            iblAscii.Name = "iblAscii";
            iblAscii.Size = new Size(564, 110);
            iblAscii.TabIndex = 4;
            iblAscii.Text = resources.GetString("iblAscii.Text");
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.MidnightBlue;
            richTextBox1.ForeColor = Color.FromArgb(0, 192, 0);
            richTextBox1.Location = new Point(-5, 1);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.ScrollBars = RichTextBoxScrollBars.ForcedHorizontal;
            richTextBox1.Size = new Size(909, 143);
            richTextBox1.TabIndex = 5;
            richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(882, 553);
            Controls.Add(richTextBox1);
            Controls.Add(iblAscii);
            Controls.Add(btnVoice);
            Controls.Add(btnSend);
            Controls.Add(txtInput);
            Controls.Add(rtbChat);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cyber Security Intelligence System";
            Load += MainForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rtbChat;
        private TextBox txtInput;
        private Button btnSend;
        private Button btnVoice;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label iblAscii;
        private RichTextBox richTextBox1;
    }
}
